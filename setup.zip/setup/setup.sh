#!/bin/bash

# Kafka setup script - installs in current directory

# Exit on error
set -e

# Update package list and install Java
echo "Updating packages and installing Java and Ansible..."
sudo apt update
sudo apt install openjdk-17-jdk -y
sudo apt install ansible-core -y
sudo apt install python3.12-venv -y
# Download and extract Kafka in current directory
echo "Downloading and extracting Kafka..."
wget https://dlcdn.apache.org/kafka/4.0.0/kafka_2.13-4.0.0.tgz -O kafka.tgz
tar -xvzf kafka.tgz
mv kafka_2.13-4.0.0 kafka
rm kafka.tgz

# Configure KRaft mode
echo "Configuring KRaft mode..."
cd kafka/config
mkdir -p kraft
cp server.properties kraft/server.properties

# Get the machine's IP address
IP=$(hostname -I | awk '{print $1}')

# Modify server.properties with the correct IP
sed -i "s/^advertised.listeners=.*/advertised.listeners=PLAINTEXT:\/\/${IP}:9092,CONTROLLER:\/\/${IP}:9093/" kraft/server.properties

echo "controller.quorum.voters=1@localhost:9093" >> kraft/server.properties
# Format storage and start Kafka
echo "Starting Kafka server..."
cd ..
KAFKA_CLUSTER_ID=$(bin/kafka-storage.sh random-uuid)
bin/kafka-storage.sh format -t $KAFKA_CLUSTER_ID -c config/kraft/server.properties

# Start Kafka in the background
nohup bin/kafka-server-start.sh config/kraft/server.properties > kafka.log 2>&1 &

# Wait for Kafka to start
echo "Waiting for Kafka to start..."
sleep 10

# Create topics
echo "Creating topics..."
bin/kafka-topics.sh --create --topic process-logs --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1
bin/kafka-topics.sh --create --topic network-logs --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1
bin/kafka-topics.sh --create --topic disk-memo-logs --bootstrap-server localhost:9092 --partitions 3 --replication-factor 1

echo ""
echo "Kafka setup completed successfully in current directory!"
echo "Kafka is running in the background."
echo "Logs are being written to: $(pwd)/kafka/kafka.log"
echo ""
echo "To stop Kafka later, run:"
echo "  $(pwd)/kafka/bin/kafka-server-stop.sh"
