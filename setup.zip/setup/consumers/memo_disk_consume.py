from kafka import KafkaConsumer
import json

consumer = KafkaConsumer(
    'disk-logs',
    bootstrap_servers='localhost:9092',
    value_deserializer=lambda m: json.loads(m.decode('utf-8')),
    auto_offset_reset='latest',
    enable_auto_commit=True
)

print("[*] Listening to disk-memo-logs topic. Press Enter to see the next message...\n")

while True:
    message = next(consumer)  # Fetch one message
    msg_value = message.value
    if "host" in msg_value:
        print(msg_value["host"])
    else:
        print("No 'host' key found in the message.")
    if "message" in msg_value:
        print(msg_value["message"])
    else:
        print("No 'message' key found in the message.")
    input("\nPress Enter to receive the next message...")

"""
{
"@timestamp": "2025-06-01T17:27:51.021Z",
"@metadata": {
"beat": "filebeat",
"type": "_doc",
"version": "8.14.0"
},
"log": {
"offset": 742,
"file": {
    "path": "/home/sibouzitoun/siem/loggers/logs/disk_memo.json",
    "device_id": "64512",
    "inode": "303588"
}
},
"message": "{\"ts\": 1748798855, \"RDDSK\": \"0\", \"WRDSK\": \"0\", \"WCANCL\": \"0\", \"DSK\": \"0.0%\", \"CMD\": \"sudo ./venv/bin/python process.py\", \"PID\": 3982}",
"input": {
"type": "filestream"
},
"fields": {
"kafka_topic": "disk-memo-logs"
},
"ecs": {
"version": "8.0.0"
},
"host": {
"hostname": "sibou",
"architecture": "x86_64",
"os": {
    "codename": "noble",
    "type": "linux",
    "platform": "ubuntu",
    "version": "24.04.2 LTS (Noble Numbat)",
    "family": "debian",
    "name": "Ubuntu",
    "kernel": "6.8.0-60-generic"
},
"id": "508272a03e794a64a1e86a105685c62b",
"name": "sibou",
"containerized": false,
"ip": [
    "192.168.85.153",
    "fe80::20c:29ff:fedb:ea8"
],
"mac": [
    "00-0C-29-DB-0E-A8"
]
},
"agent": {
"type": "filebeat",
"version": "8.14.0",
"ephemeral_id": "1c3dec6a-2c54-4e8e-8ff6-136e5ea92661",
"id": "f9909aaa-74d0-4d60-89f8-af004cca8149",
"name": "sibou"
}
}
"""
