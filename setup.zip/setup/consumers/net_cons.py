from kafka import KafkaConsumer
import json

consumer = KafkaConsumer(
    'network-logs',
    bootstrap_servers='localhost:9092',
    value_deserializer=lambda m: json.loads(m.decode('utf-8')),
    auto_offset_reset='latest',
    enable_auto_commit=True
)

print("[*] Listening to network-logs topic. Press Enter to see the next message...\n")

while True:
    message = next(consumer)  # Fetch one message
    msg_value = message.value
    if "host" in msg_value:
        print(msg_value["host"])
    else:
        print("No 'host' key found in the message.")
    if "message" in msg_value:
        print(msg_value["message"])
    else:
        print("No 'message' key found in the message.")
    input("\nPress Enter to receive the next message...")

