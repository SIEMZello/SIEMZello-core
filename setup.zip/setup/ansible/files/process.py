import os
import time
import json

LOG_FILE = "logs/process.json"
INTERVAL = 10  # seconds

def get_process_metrics(pid):
    metrics = {}
    clk_tck = os.sysconf(os.sysconf_names['SC_CLK_TCK'])
    metrics['ts'] = int(time.time())

    try:
        with open(f'/proc/{pid}/stat', 'r') as f:
            stat = f.read().split()

        utime = int(stat[13])
        stime = int(stat[14])
        total_time = (utime + stime) / clk_tck
        metrics['TRUN'] = round(total_time, 2)

        with open(f'/proc/{pid}/sched', 'r') as f:
            for line in f:
                if line.strip().startswith('policy'):
                    policy_num = int(line.strip().split()[-1])
                    break
        policy_map = {
            0: 'SCHED_OTHER', 1: 'SCHED_FIFO', 2: 'SCHED_RR',
            3: 'SCHED_BATCH', 5: 'SCHED_IDLE', 6: 'SCHED_DEADLINE'
        }
        metrics['POLI'] = policy_map.get(policy_num, f'UNKNOWN({policy_num})')

        metrics['NICE'] = int(stat[18])
        with open(f'/proc/{pid}/sched', 'r') as f:
            for line in f:
                if line.strip().startswith('prio'):
                    metrics['PRI'] = int(line.strip().split()[-1])
                    break
        metrics['CPUNR'] = int(stat[38])
        status_code = stat[2]
        metrics['Status'] = status_code
        state_map = {
            'R': 'running', 'S': 'sleeping', 'D': 'waiting', 'Z': 'zombie',
            'T': 'stopped', 't': 'tracing stop', 'W': 'paging',
            'X': 'dead', 'x': 'dead', 'K': 'wakekill', 'P': 'parked'
        }
        metrics['State'] = state_map.get(status_code, 'unknown')

        voluntary, involuntary = 0, 0
        with open(f'/proc/{pid}/status', 'r') as f:
            for line in f:
                if 'voluntary_ctxt_switches' in line:
                    voluntary = int(line.split()[-1])
                elif 'nonvoluntary_ctxt_switches' in line:
                    involuntary = int(line.split()[-1])
        metrics['EXC'] = float(voluntary + involuntary)

        try:
            with open(f'/proc/{pid}/cmdline', 'r') as f:
                cmd = f.read().replace('\x00', ' ').strip()
            if not cmd:
                cmd = stat[1].strip('()')
        except:
            cmd = 'unknown'
        metrics['CMD'] = cmd
        metrics['PID'] = pid

        def read_cpu_times():
            with open('/proc/stat', 'r') as f:
                cpu_line = f.readline()
            return sum(map(int, cpu_line.strip().split()[1:]))

        def read_proc_times():
            with open(f'/proc/{pid}/stat', 'r') as f:
                values = f.read().split()
            return int(values[13]) + int(values[14])

        total_cpu_1 = read_cpu_times()
        proc_cpu_1 = read_proc_times()
        time.sleep(1)
        total_cpu_2 = read_cpu_times()
        proc_cpu_2 = read_proc_times()

        cpu_delta = total_cpu_2 - total_cpu_1
        proc_delta = proc_cpu_2 - proc_cpu_1
        cpu_usage = (proc_delta / cpu_delta) * 100 if cpu_delta > 0 else 0.0
        metrics['CPU'] = round(cpu_usage, 1)

        return metrics

    except (FileNotFoundError, ProcessLookupError, PermissionError):
        return None

def ensure_log_dir():
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

def append_to_log(data):
    with open(LOG_FILE, 'a') as f:
        json.dump(data, f)
        f.write('\n')

def is_interesting(proc):
    return True

def monitor_loop():
    ensure_log_dir()
    while True:
        pids = [pid for pid in os.listdir("/proc") if pid.isdigit()]
        for pid in pids:
            metrics = get_process_metrics(pid)
            if is_interesting(metrics):
                append_to_log(metrics)
        time.sleep(INTERVAL)

if __name__ == "__main__":
    monitor_loop()
