import os
import json
import time
import psutil

LOG_PATH = "logs/disk_memo.json"
INTERVAL = 10  # seconds

def bytes_to_str_kb(value):
    return f"{round(value / 1024, 1)}K" if value >= 1024 else str(round(value, 1))

def get_memory_metrics(pid):
    metrics = {}
    metrics['ts'] = int(time.time())

    try:
        proc = psutil.Process(pid)
        io = proc.io_counters()

        metrics['RDDSK'] = bytes_to_str_kb(io.read_bytes)
        metrics['WRDSK'] = bytes_to_str_kb(io.write_bytes)

        # Cancelled write bytes from /proc/[pid]/io
        cancelled = 0
        with open(f'/proc/{pid}/io', 'r') as f:
            for line in f:
                if line.startswith('cancelled_write_bytes'):
                    cancelled = int(line.split()[-1])
                    break
        metrics['WCANCL'] = bytes_to_str_kb(cancelled)

        # Disk utilization (global, not per-process)
        d1 = psutil.disk_io_counters()
        t1 = time.time()
        time.sleep(1)
        d2 = psutil.disk_io_counters()
        t2 = time.time()
        delta_time = t2 - t1
        delta_read = d2.read_bytes - d1.read_bytes
        delta_write = d2.write_bytes - d1.write_bytes
        bytes_per_sec = (delta_read + delta_write) / delta_time
        max_bytes = 500 * 1024 * 1024  # 500MB/s max capacity
        dsk_util = min((bytes_per_sec / max_bytes) * 100, 100)
        metrics['DSK'] = f"{round(dsk_util, 1)}%"

        metrics['CMD'] = " ".join(proc.cmdline()) or proc.name()
        metrics['PID'] = pid

    except (psutil.NoSuchProcess, FileNotFoundError, ProcessLookupError, PermissionError):
        return None

    return metrics

def is_interesting(proc):
    try:
        if proc.username() != os.getlogin():
            return False
        if proc.status() in (psutil.STATUS_ZOMBIE, psutil.STATUS_DEAD):
            return False
        if not proc.cmdline():
            return False
        return True
    except (psutil.NoSuchProcess, PermissionError):
        return False

def main():
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)

    print(f"[*] Logging disk/memory metrics every {INTERVAL} seconds to {LOG_PATH}")
    while True:
        all_metrics = []

        for proc in psutil.process_iter(attrs=[]):
            if not is_interesting(proc):
                continue

            metrics = get_memory_metrics(proc.pid)
            if metrics:
                all_metrics.append(metrics)

        if all_metrics:
            with open(LOG_PATH, 'a') as f:
                for entry in all_metrics:
                    f.write(json.dumps(entry) + "\n")

        time.sleep(INTERVAL)

if __name__ == "__main__":
    main()
