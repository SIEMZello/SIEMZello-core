#!/usr/bin/env python3
from flask import Flask, jsonify
from flask_httpauth import HTTPBasicAuth
import psutil
import time
import socket

app = Flask(__name__)
auth = HTTPBasicAuth()

# ===== Configuration =====
API_PORT = 5050
API_USER = "siem"        # Change this!
API_PASS = "pass"  # Change this!
# =========================

users = {API_USER: API_PASS}

@auth.verify_password
def verify_password(username, password):
    if username in users and users[username] == password:
        return username

def get_system_info():
    """Collects comprehensive system metrics"""
    try:
        # CPU Metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        per_cpu = psutil.cpu_percent(interval=1, percpu=True)
        
        # Memory Metrics
        mem = psutil.virtual_memory()
        swap = psutil.swap_memory()
        
        # Disk Metrics
        disk = psutil.disk_usage('/')
        disk_io = psutil.disk_io_counters()
        
        # Network
        net_io = psutil.net_io_counters()
        hostname = socket.gethostname()
        
        return {
            'timestamp': time.time(),
            'hostname': hostname,
            'cpu': {
                'total_usage': cpu_percent,
                'per_core': per_cpu,
                'cores': psutil.cpu_count(),
                'load_avg': psutil.getloadavg()
            },
            'memory': {
                'total': mem.total,
                'available': mem.available,
                'used': mem.used,
                'percent': mem.percent,
                'swap_total': swap.total,
                'swap_used': swap.used
            },
            'disk': {
                'total': disk.total,
                'used': disk.used,
                'free': disk.free,
                'percent': disk.percent,
                'read_bytes': disk_io.read_bytes if disk_io else 0,
                'write_bytes': disk_io.write_bytes if disk_io else 0
            },
            'network': {
                'bytes_sent': net_io.bytes_sent,
                'bytes_recv': net_io.bytes_recv
            }
        }
    except Exception as e:
        return {'error': str(e)}

@app.route('/metrics', methods=['GET'])
@auth.login_required
def get_metrics():
    """Returns all system metrics"""
    metrics = get_system_info()
    if 'error' in metrics:
        return jsonify(metrics), 500
    return jsonify(metrics)

@app.route('/health', methods=['GET'])
def health_check():
    """Simple health endpoint"""
    return jsonify({'status': 'healthy', 'timestamp': time.time()})

if __name__ == '__main__':
    # Security recommendation: Don't run as root
    if psutil.Process().username() == 'root':
        print("WARNING: Running as root is not recommended!")
    
    app.run(
        host='0.0.0.0',
        port=API_PORT,
        threaded=True
    )
