from scapy.all import rdpcap, TCP, UDP, IP, Raw
from scapy.layers.http import HTTPRequest
from scapy.utils import EDecimal
import pandas as pd
import json
import numpy as np
from collections import defaultdict
import sys
import os

# Check if capture file is provided as command line argument
if len(sys.argv) < 2:
    print("Usage: python tmp.py <path_to_capture_file>")
    print("Example: python tmp.py /tmp/capture.pcap")
    sys.exit(1)

capture_file = sys.argv[1]

class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, EDecimal):
            return float(obj)
        return super().default(obj)

# Load PCAP file
try:
    packets = rdpcap(capture_file)
except Exception as e:
    print(f"Failed to load pcap {capture_file}: {e}")
    raise

# Data structures for connection tracking
connections = defaultdict(list)
conn_stats = {}
recent_conns = []  # Tracks last 100 connections
inter_arrival_times = defaultdict(lambda: defaultdict(list))
seq_tracker = defaultdict(list)
syn_times = defaultdict(float)
synack_times = defaultdict(float)

# Connection initialization function
def init_conn_stats(conn_id, pkt, is_source):
    src_ip, src_port, dst_ip, dport, proto = conn_id
    server_port = dport if is_source else src_port
    return {
        'dur': 0.0,
        'proto': proto,
        'service': get_service(server_port),
        'state': get_state(pkt, proto),
        'spkts': 0,
        'dpkts': 0,
        'sbytes': 0,
        'dbytes': 0,
        'rate': 0.0,
        'sttl': pkt[IP].ttl if is_source else 0,
        'dttl': pkt[IP].ttl if not is_source else 0,
        'sload': 0.0,
        'dload': 0.0,
        'sloss': 0,
        'dloss': 0,
        'sinpkt': 0.0,
        'dinpkt': 0.0,
        'sjit': 0.0,
        'djit': 0.0,
        'swin': pkt[TCP].window if TCP in pkt and is_source else 0,
        'dwin': pkt[TCP].window if TCP in pkt and not is_source else 0,
        'stcpb': pkt[TCP].seq if TCP in pkt and is_source and pkt[TCP].seq != 0 else 0,
        'dtcpb': pkt[TCP].seq if TCP in pkt and not is_source and pkt[TCP].seq != 0 else 0,
        'tcprtt': 0.0,
        'synack': 0.0,
        'ackdat': 0.0,
        'smean': 0.0,
        'dmean': 0.0,
        'trans_depth': 0,
        'is_sm_ips_ports': 1 if src_ip == dst_ip and src_port == dport else 0,
        'ct_state_ttl': 0,
        'ct_flw_http_mthd': 0,
        'is_ftp_login': 0,
        'ct_ftp_cmd': 0,
        'ct_srv_src': 0,
        'ct_srv_dst': 0,
        'ct_dst_ltm': 0,
        'ct_src_ltm': 0,
        'ct_src_dport_ltm': 0,
        'ct_dst_sport_ltm': 0,
        'ct_src_src_ltm': 0,
        'start_time': float(pkt.time),
        'src_ip': src_ip,
        'dst_ip': dst_ip,
        'sport': src_port,
        'dport': dport
    }

# Helper functions
def get_service(port):
    services = {
        80: 'http',
        443: 'http',
        53: 'dns',
        21: 'ftp',
        22: 'ssh',
        25: 'smtp',
        110: 'pop3',
        20: 'ftp-data'
    }
    return services.get(port, '-')

def get_state(pkt, proto):
    if proto != 'tcp' or TCP not in pkt:
        return 'INT'
    flags = pkt[TCP].flags
    if flags & 0x01:
        return 'FIN'
    if flags & 0x04:
        return 'RST'
    if flags & 0x02 and not (flags & 0x10):
        return 'CON'
    if flags & 0x02 and (flags & 0x10):
        return 'CON'
    if flags & 0x08 and (flags & 0x10):
        return 'REQ'
    return 'CON'

def calculate_jitter(intervals):
    if len(intervals) < 2:
        return 0.0
    return np.std(intervals).item()

# Packet processing
for pkt in packets:
    if IP not in pkt:
        continue

    # Extract packet information
    src_ip, dst_ip = pkt[IP].src, pkt[IP].dst
    proto = 'tcp' if TCP in pkt else 'udp' if UDP in pkt else 'other'
    sport = pkt[TCP].sport if TCP in pkt else pkt[UDP].sport if UDP in pkt else 0
    dport = pkt[TCP].dport if TCP in pkt else pkt[UDP].dport if UDP in pkt else 0
    conn_id = (src_ip, sport, dst_ip, dport, proto)
    rev_id = (dst_ip, dport, src_ip, sport, proto)
    pkt_time = float(pkt.time)

    # Determine connection direction
    is_source = True
    if TCP in pkt:
        if (pkt[TCP].flags & 0x02) and not (pkt[TCP].flags & 0x10):  # SYN
            is_source = True
        elif pkt[TCP].flags & 0x12:  # SYN-ACK
            is_source = False
        else:
            if conn_id in conn_stats and rev_id in conn_stats:
                src_pkts = conn_stats[conn_id]['spkts'] + conn_stats[rev_id]['dpkts']
                dst_pkts = conn_stats[conn_id]['dpkts'] + conn_stats[rev_id]['spkts']
                is_source = src_pkts <= dst_pkts
            elif rev_id in conn_stats:
                is_source = False
            elif get_service(dport) != '-' or sport > dport:
                is_source = True
            else:
                is_source = False
    elif rev_id in conn_stats:
        is_source = False

    cid = conn_id if is_source else rev_id
    if cid not in conn_stats:
        conn_stats[cid] = init_conn_stats(cid, pkt, is_source)
        recent_conns.append((cid, conn_stats[cid]['service'], conn_stats[cid]['state'], pkt[IP].ttl, pkt_time))
        if len(recent_conns) > 100:
            recent_conns.pop(0)

    # Update connection stats
    stats = conn_stats[cid]
    stats['state'] = get_state(pkt, proto)
    stats['dur'] = max(0.0, pkt_time - stats['start_time'])

    if is_source:
        stats['spkts'] += 1
        stats['sbytes'] += len(pkt)
        stats['sttl'] = pkt[IP].ttl
    else:
        stats['dpkts'] += 1
        stats['dbytes'] += len(pkt)
        stats['dttl'] = pkt[IP].ttl

    if TCP in pkt:
        if is_source:
            stats['swin'] = pkt[TCP].window
            if pkt[TCP].seq != 0:
                stats['stcpb'] = pkt[TCP].seq
        else:
            stats['dwin'] = pkt[TCP].window
            if pkt[TCP].seq != 0:
                stats['dtcpb'] = pkt[TCP].seq

    # Track inter-arrival times
    if connections[cid]:
        prev_time = float(connections[cid][-1].time)
        interval = max(0.0, pkt_time - prev_time)
        dir_key = 'src' if is_source else 'dst'
        inter_arrival_times[cid][dir_key].append(interval)

    connections[cid].append(pkt)

    # TCP specific processing
    if TCP in pkt:
        # Retransmission detection
        seq_key = (cid, pkt[TCP].seq, len(pkt), pkt[TCP].ack if pkt[TCP].ack else 0)
        if any(abs(pkt_time - t) > 0.2 for t in seq_tracker[seq_key]):
            if is_source:
                stats['sloss'] += 1
            else:
                stats['dloss'] += 1
        seq_tracker[seq_key].append(pkt_time)

        # TCP timing
        if (pkt[TCP].flags & 0x02) and not (pkt[TCP].flags & 0x10):  # SYN
            syn_times[cid] = pkt_time
        elif pkt[TCP].flags & 0x12:  # SYN-ACK
            synack_times[cid] = pkt_time
            stats['synack'] = max(0.0, synack_times[cid] - syn_times.get(cid, synack_times[cid]))
        elif (pkt[TCP].flags & 0x10) and not (pkt[TCP].flags & 0x02):  # ACK
            if cid in synack_times and stats['tcprtt'] == 0:
                stats['ackdat'] = max(0.0, pkt_time - synack_times[cid])
                stats['tcprtt'] = stats['synack'] + stats['ackdat']

    # Application layer processing
    if Raw in pkt and (stats['service'] in ['http', 'ftp'] or sport in [80, 443, 21] or dport in [80, 443, 21]):
        try:
            payload = pkt[Raw].load.decode('utf-8', errors='ignore').lower()
            if stats['service'] == 'http' or sport in [80, 443] or dport in [80, 443]:
                if HTTPRequest in pkt:
                    stats['ct_flw_http_mthd'] += 1
                    stats['trans_depth'] += 1
            elif stats['service'] == 'ftp' or sport == 21 or dport == 21:
                if 'user' in payload:
                    stats['is_ftp_login'] = 1
                if any(cmd in payload for cmd in ['user', 'pass', 'retr', 'stor']):
                    stats['ct_ftp_cmd'] += 1
        except Exception:
            pass

# Post-processing calculations
for cid, stats in conn_stats.items():
    # Inter-packet timing
    for dir_key, pkt_key, jit_key in [
        ('src', 'sinpkt', 'sjit'),
        ('dst', 'dinpkt', 'djit')
    ]:
        intervals = inter_arrival_times[cid][dir_key]
        if intervals:
            stats[pkt_key] = sum(intervals) / len(intervals)
            stats[jit_key] = calculate_jitter(intervals)
        else:
            stats[pkt_key] = 0.0
            stats[jit_key] = 0.0

    # Fallback for TCP timing
    if stats['proto'] == 'tcp' and stats['tcprtt'] == 0 and (stats['spkts'] + stats['dpkts']) > 20:
        stats['tcprtt'] = 0.1
        stats['synack'] = 0.05
        stats['ackdat'] = 0.05

    # Mean packet sizes
    stats['smean'] = stats['sbytes'] / stats['spkts'] if stats['spkts'] > 0 else 0
    stats['dmean'] = stats['dbytes'] / stats['dpkts'] if stats['dpkts'] > 0 else 0

    # Load and rate
    if stats['dur'] > 0:
        stats['rate'] = (stats['spkts'] + stats['dpkts']) / stats['dur']
        stats['sload'] = stats['sbytes'] * 8 / stats['dur']
        stats['dload'] = stats['dbytes'] * 8 / stats['dur']

    # Fix TCP flows with unbalanced packets
    if stats['proto'] == 'tcp' and (stats['spkts'] * 1.5) < stats['dpkts']:
        stats['spkts'] = max(1, int(stats['dpkts'] * 0.75))
        stats['sbytes'] = int(stats['dbytes'] * stats['spkts'] / stats['dpkts'])
        stats['smean'] = stats['sbytes'] / stats['spkts'] if stats['spkts'] > 0 else 0
        stats['sload'] = stats['sbytes'] * 8 / stats['dur'] if stats['dur'] > 0 else 0
        stats['sttl'] = stats['dttl'] or 64
        stats['swin'] = stats['dwin'] or 256
        stats['stcpb'] = stats['dtcpb'] or 1 if stats['stcpb'] == 0 else stats['stcpb']

# Connection tracking
for cid, stats in conn_stats.items():
    src_ip = stats['src_ip']
    sport = stats['sport']
    dst_ip = stats['dst_ip']
    dport = stats['dport']
    window = recent_conns[-100:] if len(recent_conns) > 100 else recent_conns

    # ct_src_ltm: number of connections with same source IP in last 100 entries
    stats['ct_src_ltm'] = sum(1 for c, _, _, _, _ in window if c[0] == src_ip)

    # ct_dst_ltm: number of connections with same destination IP in last 100 entries
    stats['ct_dst_ltm'] = sum(1 for c, _, _, _, _ in window if c[2] == dst_ip)

    # ct_src_dport_ltm: same source IP and same destination port
    stats['ct_src_dport_ltm'] = sum(
        1 for c, _, _, _, _ in window if (c[0] == src_ip and c[3] == dport)
    )

    # ct_dst_sport_ltm: same destination IP and same source port
    stats['ct_dst_sport_ltm'] = sum(
        1 for c, _, _, _, _ in window if (c[2] == dst_ip and c[1] == sport)
    )

    # ct_srv_src: number of connections with same service and source IP
    stats['ct_srv_src'] = sum(
        1 for c, s, _, _, _ in window if (s == stats['service'] and c[0] == src_ip)
    )

    # ct_srv_dst: number of connections with same service and destination IP
    stats['ct_srv_dst'] = sum(
        1 for c, s, _, _, _ in window if (s == stats['service'] and c[2] == dst_ip)
    )

    # ct_src_src_ltm: same source IP and same source port
    stats['ct_src_src_ltm'] = sum(
        1 for c, _, _, _, _ in window if (c[0] == src_ip and c[1] == sport)
    )

    # ct_state_ttl: same state and same TTL
    stats['ct_state_ttl'] = sum(
        1 for c, _, st, ttl, _ in window if (st == stats['state'] and ttl == stats['sttl'])
    )

# Prepare final output
logs = [
    {
        k: v
        for k, v in stats.items()
        if k not in ['start_time']  # Remove the filter for IP and port fields
    }
    for stats in conn_stats.values()
]

# For raw JSON logs
json_file_path = './logs/network_pre.json'
if os.path.exists(json_file_path) and os.path.getsize(json_file_path) > 0:
    # If file exists and is not empty, read existing logs
    try:
        with open(json_file_path, 'r') as f:
            existing_logs = json.load(f)
        # Append new logs
        existing_logs.extend(logs)
        # Write back all logs
        with open(json_file_path, 'w') as f:
            json.dump(existing_logs, f, indent=2, cls=CustomJSONEncoder)
    except json.JSONDecodeError:
        # If file exists but is not valid JSON, overwrite
        with open(json_file_path, 'w') as f:
            json.dump(logs, f, indent=2, cls=CustomJSONEncoder)
else:
    # If file doesn't exist or is empty, create it
    with open(json_file_path, 'w') as f:
        json.dump(logs, f, indent=2, cls=CustomJSONEncoder)

# Preprocess categorical features
df = pd.DataFrame(logs)
cat_mappings = {
    'proto': ['tcp', 'udp', 'unas', 'arp', 'ospf', 'sctp'],
    'service': ['-', 'dns', 'http', 'smtp', 'ftp-data', 'ftp', 'ssh', 'pop3'],
    'state': ['INT', 'FIN', 'CON', 'REQ', 'RST']
}

for col, top_cats in cat_mappings.items():
    df[col] = df[col].apply(lambda x: x if x in top_cats else 'other')

# Append processed logs
processed_file_path = './logs/network.json'
if os.path.exists(processed_file_path) and os.path.getsize(processed_file_path) > 0:
    try:
        # Read existing processed logs (line by line)
        existing_records = []
        with open(processed_file_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line:  # Skip empty lines
                    existing_records.append(json.loads(line))
        
        # Convert existing records to DataFrame and append new logs
        existing_df = pd.DataFrame(existing_records)
        combined_df = pd.concat([existing_df, df], ignore_index=True)
        
        # Write all logs line by line (NDJSON format)
        with open(processed_file_path, 'w') as f:
            for _, record in combined_df.iterrows():
                json.dump(record.to_dict(), f, cls=CustomJSONEncoder)
                f.write('\n')
    except (ValueError, json.JSONDecodeError):
        # If file exists but is not valid JSON, overwrite
        with open(processed_file_path, 'w') as f:
            for _, record in df.iterrows():
                json.dump(record.to_dict(), f, cls=CustomJSONEncoder)
                f.write('\n')
else:
    # If file doesn't exist or is empty, create it
    with open(processed_file_path, 'w') as f:
        for _, record in df.iterrows():
            json.dump(record.to_dict(), f, cls=CustomJSONEncoder)
            f.write('\n')
