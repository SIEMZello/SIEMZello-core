#!/bin/bash

INTERFACE="ens33"
CAPTURE_DIR="./logs"
PCAP_DIR="./captures"
PROCESS_SCRIPT="network.py"
VENV_PATH="./venv"  # Change this to your actual virtual environment path
INTERVAL=10

mkdir -p "$CAPTURE_DIR" "$PCAP_DIR"

# Activate the virtual environment
source "$VENV_PATH/bin/activate"

while true; do
    TIMESTAMP=$(date +%s)
    PCAP_FILE="${PCAP_DIR}/capture_${TIMESTAMP}.pcap"

    echo "[*] Capturing for $INTERVAL seconds..."
    sudo timeout "$INTERVAL" tcpdump -i "$INTERFACE" -w "$PCAP_FILE" -n

    echo "[*] Processing $PCAP_FILE..."
    python "$PROCESS_SCRIPT" "$PCAP_FILE"
done
